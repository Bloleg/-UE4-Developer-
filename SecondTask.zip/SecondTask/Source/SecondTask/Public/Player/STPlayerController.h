// SecondTask

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "STPlayerController.generated.h"

/**
 * 
 */
UCLASS()
class SECONDTASK_API ASTPlayerController : public APlayerController
{
	GENERATED_BODY()
	
};
