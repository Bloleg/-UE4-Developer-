// SecondTask

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "STHubActor.generated.h"

UCLASS()
class SECONDTASK_API ASTHubActor : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ASTHubActor();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	
	//UPROPERTY(EditAnywhere)
	//TSubclassOf<ABaseGeometryActor> GeometryClass;
	//TSubclassOf<ASTGameModeBase> GeometryClass;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

};
