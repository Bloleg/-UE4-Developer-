// SecondTask

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "STGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class SECONDTASK_API ASTGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
public:
	ASTGameModeBase();
	
};
