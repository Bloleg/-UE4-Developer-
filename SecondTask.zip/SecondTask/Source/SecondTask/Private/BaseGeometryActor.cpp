// SecondTask


#include "BaseGeometryActor.h"
#include "Engine/Engine.h"

// Sets default values
ABaseGeometryActor::ABaseGeometryActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	BaseMesh = CreateDefaultSubobject<UStaticMeshComponent>("BaseMesh");
	SetRootComponent(BaseMesh);
}

// Called when the game starts or when spawned
void ABaseGeometryActor::BeginPlay()
{
	Super::BeginPlay();


	InitialLocation = GetActorLocation();

	FVector CurrentLocation = GetActorLocation();
	if (GetWorld())
	{
		float Time = GetWorld()->GetTimeSeconds();
		CurrentLocation.Z = InitialLocation.Z + Amplitude * FMath::Sin(Frequency * Time);

		SetActorLocation(CurrentLocation);
	}

	//FTransform Transform = GetActorTransform();
	//FVector Location = Transform.GetLocation();
	//FRotator Rotation = Transform.Rotator();
	//FVector Scale = Transform.GetScale3D();
}

// Called every frame
void ABaseGeometryActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

