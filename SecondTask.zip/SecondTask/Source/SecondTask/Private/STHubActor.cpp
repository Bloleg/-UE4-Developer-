// SecondTask


#include "STHubActor.h"
#include "Engine/world.h"

// Sets default values
ASTHubActor::ASTHubActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ASTHubActor::BeginPlay()
{
	Super::BeginPlay();
	UWorld* Wprld = GetWorld();
	if (Wprld)
	{
	//	Wprld->SpawnActor(GeometryClass);
	}
	
}

// Called every frame
void ASTHubActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

