// SecondTask

#include "SecondTask.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, SecondTask, "SecondTask" );
